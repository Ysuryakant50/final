package com.ecom.orderservice.controller;

import com.ecom.orderservice.clients.ProductClient;
import com.ecom.orderservice.dto.ProductDTO;
import com.ecom.orderservice.models.Order;
import com.ecom.orderservice.repositories.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
    private OrderRepository orderRepository;
    
	@Autowired
	private ProductClient productClient;

	@PostMapping
	public ResponseEntity<?> placeOrder(@RequestBody Order order) {
	    ProductDTO product = productClient.getProductById(order.getProductId());

	    if (product == null) {
	        return ResponseEntity.badRequest().body("Product not found");
	    }

	    if (order.getQuantity() > product.getQuantity()) {
	        return ResponseEntity.badRequest().body("Insufficient stock");
	    }

	    // Reduce stock
	    productClient.reduceStock(order.getProductId(), order.getQuantity());

	    // Calculate total price and save order
	    order.setTotalPrice(product.getPrice() * order.getQuantity());
	    order.setOrderDate(LocalDateTime.now());

	    return ResponseEntity.ok(orderRepository.save(order));
	}



    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        return orderRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteOrder(@PathVariable Long id) {
        return orderRepository.findById(id)
                .map(order -> {
                    orderRepository.delete(order);
                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
