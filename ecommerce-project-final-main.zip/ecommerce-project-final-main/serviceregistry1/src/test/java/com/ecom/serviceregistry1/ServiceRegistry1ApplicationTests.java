package com.ecom.serviceregistry1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistry1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
